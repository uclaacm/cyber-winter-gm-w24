Steps to run:
1. Install node.js: https://nodejs.org/en/download
2. Install packages by running `npm install` while in the directory in a command prompt
3. Run by running `npm start`
4. Visit the site at http://localhost:3000

If you need help running this locally, please ask any officer and we're happy to help, but we also have a copy of this code running 
on the site!
